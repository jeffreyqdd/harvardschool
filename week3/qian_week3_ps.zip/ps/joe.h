void display_menu();
bool is_mon();
void apply_monday(int &numDogs, int &numFries, int &numDrinks);
double round_num(double d);
void calculate_total(double &subtotal, double &discount, double &tax, const int order[]);
