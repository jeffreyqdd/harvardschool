//gamerules

#define STARTING_MONEY 2000
#define ADD_MONEY 200
#define MAX_DOUBLE_ROLL 3
#define BANKRUPTCY 0
#define INCOME_TAX 0.10
#define DATA "game_data.txt"
#define MAX_PLAYERS 4