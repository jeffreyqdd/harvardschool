namespace Display
{
    void display_player(string, int); //gives cool banner inlcuding player name and balance
    void display_event(string); //incorporates delay
    void delay(int); //delay function..using chrono and thread
    void display_tile(string, int, string, string); //display tile with delay.
    void display_text(string);
}