char *init_char();
char *append_char(char a[], char s);
int get_char_length(char c[]);